public interface Countable {
    double count();
}
