import java.util.ArrayList;import java.util.Scanner;
public class Main {
    public static void main(String[] args) {


    Sweets snickers = new Sweets(101, "Snickers", 4500, 0);
    Sweets alpenGold = new Sweets(102, "Alpen Gold", 3000, 0);
    Sweets bounty = new Sweets(103, "Bounty", 1000, 0);
    Sweets polet = new Sweets(104, "Polet", 1200, 0);
    Sweets milka = new Sweets(105, "Milka", 5000, 0);

    Meat beef = new Meat(201, "Beef", 5000, 0);
    Meat chicken = new Meat(202, "Chicken", 3000, 0);
    Meat turkey = new Meat(203, "Turkey", 6000, 0);
    Meat bear = new Meat(204, "Bear", 25000, 0);
    Meat rabbit = new Meat(205, "Rabbit", 3000, 0);

    Fruit apple = new Fruit(301, "Apple", 500, 0);
    Fruit orange = new Fruit(302, "Orange", 2000, 0);
    Fruit pineapple = new Fruit(303, "Pineapple", 3000, 0);
    Fruit banana = new Fruit(304, "Banana", 1050, 0);
    Fruit melon = new Fruit(305, "Melon", 1500, 0);

    Bakery bread = new Bakery(401, "Bread", 150, 0);
    Bakery bagels = new Bakery(402, "Bagels", 240, 0);
    Bakery buns = new Bakery(403, "Buns", 270, 0);
    Bakery rolls = new Bakery(404, "Rolls", 160, 0);
    Bakery cake = new Bakery(405, "Cake", 4000, 0);

    Milk milk = new Milk(501, "Milk", 450, 0);
    Milk butter = new Milk(502, "Butter", 2000, 0);
    Milk cheese = new Milk(503, "Cheese", 2500, 0);
    Milk airan = new Milk(504, "Airan", 400, 0);
    Milk yogurt = new Milk(505, "Yogurt", 200, 0);

    ArrayList<Sweets> sweets = new ArrayList<>(); //change
    sweets.add(snickers);
    sweets.add(alpenGold);
    sweets.add(bounty);
    sweets.add(polet);
    sweets.add(milka);

    ArrayList<Meat> meat = new ArrayList<>();
    meat.add(beef);
    meat.add(chicken);
    meat.add(turkey);
    meat.add(bear);
    meat.add(rabbit);

    ArrayList<Fruit> fruits = new ArrayList<>();
    fruits.add(apple);
    fruits.add(orange);
    fruits.add(pineapple);
    fruits.add(banana);
    fruits.add(melon);

    ArrayList<Bakery> bakeries = new ArrayList<>();
    bakeries.add(bread);
    bakeries.add(bagels);
    bakeries.add(buns);
    bakeries.add(rolls);
    bakeries.add(cake);

    ArrayList<Milk> milks = new ArrayList<>();
    milks.add(milk);
    milks.add(cheese);
    milks.add(airan);
    milks.add(yogurt);
    milks.add(butter);

    Scanner scanner = new Scanner(System.in);
    System.out.println("Write balance ");        double balance = scanner.nextDouble();
    boolean running = true;        while (running) {
        System.out.println("\n**********************************************");
        System.out.println("You have the following available functions:");
        System.out.println("1) To order a products");
        System.out.println("2) To fill a cart");
        System.out.println("3) To delete a product");
        System.out.println("4) To watch a cart");
        System.out.println("5) To watch a total price");
        System.out.println("6) To finish");
        System.out.print("Choose a function: ");
        String input = scanner.next();
        switch (input) {
            case "1":
                System.out.println("1)Sweets" + "\n" + "2)Meat" + "\n" + "3)Fruit" + "\n" + "4)Bakery" + "\n" + "5)Milk");
                System.out.print("Choose a product department: ");
                String input1 = scanner.next();
                switch (input1) {
                    case "1":
                        printDataS(sweets);
                        break;
                    case "2":
                        printDataM(meat);
                        break;
                    case "3":
                        printDataF(fruits);
                        break;
                    case "4":
                        printDataB(bakeries);
                        break;
                    case "5":
                        printDataMilk(milks);
                        break;
                }
                break;
            case "2":
                fill(sweets, meat, fruits, bakeries, milks);
                break;
            case "3":
                delete(sweets, meat, fruits, bakeries, milks);
                break;
            case "4":
                watch(balance, sweets, meat, fruits, bakeries, milks);
                break;
            case "5":
                System.out.println(price(sweets, meat, fruits, bakeries, milks) + " tenge");
                break;
            case "6":
                System.out.println(price(sweets, meat, fruits, bakeries, milks) + " tenge");
                running = false;
                break;
        }
    }
}
    public static void printDataS(ArrayList<Sweets> sweets) {
        for (Product product : sweets) {
            System.out.println(product.toString());
        }
}
    public static void printDataM(ArrayList<Meat> meat) {
        for (Product product : meat) {
            System.out.println(product.toString());
        }
}
    public static void printDataF(ArrayList<Fruit> fruits) {
        for (Product product : fruits) {
            System.out.println(product.toString());
        }
}
    public static void printDataB(ArrayList<Bakery> bakeries) {
        for (Product product : bakeries) {
            System.out.println(product.toString());
        }
}
    public static void printDataMilk(ArrayList<Milk> milks) {
        for (Product product : milks) {
            System.out.println(product.toString());
        }
}
    public static double price(ArrayList<Sweets> sweets, ArrayList<Meat> meat, ArrayList<Fruit> fruits, ArrayList<Bakery> bakeries, ArrayList<Milk> milks){
        double totalPrice = 0;
        for(int i = 0; i < 5; i++){
            totalPrice += sweets.get(i).count() + meat.get(i).count() + fruits.get(i).count() + bakeries.get(i).count() + milks.get(i).count();        }
        return(totalPrice);
}
    public static void fill(ArrayList<Sweets> sweets, ArrayList<Meat> meat, ArrayList<Fruit> fruits, ArrayList<Bakery> bakeries, ArrayList<Milk> milks) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Write id");
        int idnow = scanner.nextInt();
        System.out.println("Write weight(sweets, meat, fruits)/amount(bakery, milk)");
        double weight = scanner.nextDouble();
        if (idnow > 100 && idnow < 106) {
            sweets.get(idnow - 101).setWeightS(weight);
        } else if (idnow > 200 && idnow < 206) {
            meat.get(idnow - 201).setWeightM(weight);
        } else if (idnow > 300 && idnow < 306) {
            fruits.get(idnow - 301).setWeightF(weight);
        } else if (idnow > 400 && idnow < 406) {
            bakeries.get(idnow - 401).setAmountB(weight);
        } else if (idnow > 500 && idnow < 506) {
            milks.get(idnow - 501).setAmountM(weight);
        }
    }
    public static void delete(ArrayList<Sweets> sweets, ArrayList<Meat> meat, ArrayList<Fruit> fruits, ArrayList<Bakery> bakeries, ArrayList<Milk> milks){        Scanner scanner = new Scanner(System.in);
        System.out.println("Write id ");
        int idnow2 = scanner.nextInt();
        if (idnow2 > 100 && idnow2< 106) {
            sweets.get(idnow2 - 101).setWeightS(0);
        }
        else if (idnow2 > 200 && idnow2 < 206) {
            meat.get(idnow2-201).setWeightM(0);
        }
        else if (idnow2 > 300 && idnow2 < 306) {
            fruits.get(idnow2 - 301).setWeightF(0);
        }
        else if (idnow2 > 400 && idnow2 < 406) {
            bakeries.get(idnow2 - 401).setAmountB(0);
        }
        else if(idnow2>500 && idnow2<506) {
            milks.get(idnow2 - 501).setAmountM(0);
        }
}
    public static void watch(double balance, ArrayList<Sweets> sweets, ArrayList<Meat> meat, ArrayList<Fruit> fruits, ArrayList<Bakery> bakeries, ArrayList<Milk> milks){        Scanner scanner = new Scanner(System.in);
        System.out.println("Sweets: ");
        for(int i=0; i<5;i++) {
            if(sweets.get(i).getWeightS()>0) {
                System.out.println(sweets.get(i).getName()+" "+sweets.get(i).getWeightS()+" ");
            }
        }
        System.out.println();
        System.out.println("Meat: ");
        for(int i=0; i<5;i++) {
            if(meat.get(i).getWeightM()>0) {
                System.out.println(meat.get(i).getName()+" "+meat.get(i).getWeightM()+" ");
            }
        }
        System.out.println();        System.out.println("Fruits: ");
        for(int i=0; i<5;i++) {            if(fruits.get(i).getWeightF()>0) {
            System.out.println(fruits.get(i).getName()+" "+fruits.get(i).getWeightF()+" ");            }
        }
        System.out.println();        System.out.println("Bakeries: ");
        for(int i=0; i<5;i++) {
            if(bakeries.get(i).getAmountB()>0) {                System.out.println(bakeries.get(i).getName()+" "+bakeries.get(i).getAmountB()+" ");
            }
        }        System.out.println();
        System.out.println("Milks: ");        for(int i=0; i<5;i++) {
            if(milks.get(i).getAmountM()>0) {
                System.out.print(milks.get(i).getName()+" "+milks.get(i).getAmountM()+" ");            }
        }
        System.out.println();
        if(balance < price(sweets, meat, fruits, bakeries, milks)){            System.out.println("\033[31m_________________________");
            System.out.println("|Balance is insufficient|");            System.out.println("|You must edit your cart|");
            System.out.println("_________________________\033[0m");        }
    }
}
