public class Fruit extends Product{
    private double weightF;

    public Fruit(int id, String name, double price, double weightF){
        super(id, name, price);
        this.weightF = weightF;
    }
    public Fruit(){

    }

    public double getWeightF(){
        return weightF;
    }
    public void setWeightF(double weightF) {
        this.weightF = weightF;
    }

    @Override
    public double count(){
        return getPrice()*getWeightF();
    }
}

