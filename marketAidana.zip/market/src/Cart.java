public class Cart{
    Product product = new Product();
    Sweets sweets = new Sweets();
    private double price = product.count();
    private int id = product.getId();

    public Cart(){

    }
    public Cart(int id, double price){
        this.id = id;
        this.price = price;
    }
}
